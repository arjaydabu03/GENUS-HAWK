<?php
namespace App\Message;

class Message{
    
}