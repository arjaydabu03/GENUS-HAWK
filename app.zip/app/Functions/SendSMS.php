<?php

namespace App\Functions;
use Illuminate\Support\Facades\Http;

class SendSMS
{
    public static function send($type, $requestor_no)
    {
        $response = "Fresh morning! error encountered\n" . $type;
        if ($type === "success") {
            $response = "Fresh Morning\nAll orders succesfully sent!";
        }

        $response = Http::withBasicAuth("rdf_vince", "rdfPampanga@2023")->post(
            "https://gn4l6.api.infobip.com/sms/2/text/advanced",
            [
                "messages" => [
                    [
                        "destinations" => [
                            [
                                "to" => "$requestor_no",
                            ],
                        ],
                        "from" => "RDF-MIS",
                        "text" => $response,
                    ],
                ],
            ]
        );
    }
}
